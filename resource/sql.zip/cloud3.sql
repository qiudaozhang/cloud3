/*
SQLyog Ultimate v13.1.1 (64 bit)
MySQL - 8.0.31-0ubuntu0.20.04.1 : Database - cloud3
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
USE `cloud3`;

/*Table structure for table `auth` */

DROP TABLE IF EXISTS `auth`;

CREATE TABLE `auth` (
  `id` bigint NOT NULL COMMENT '主键',
  `username` varchar(255) DEFAULT NULL COMMENT '用户名',
  `password` varchar(255) DEFAULT NULL COMMENT '密码',
  `phone` varchar(255) DEFAULT NULL COMMENT '手机号',
  `email` varchar(255) DEFAULT NULL COMMENT '邮箱',
  `created` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` int DEFAULT '0' COMMENT '逻辑删除 0 未删除 1 已删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `auth` */

insert  into `auth`(`id`,`username`,`password`,`phone`,`email`,`created`,`updated`,`deleted`) values 
(390549286953029,'dao','$2a$10$LYSPsUBS1z2nLidwA72mq.gpvRd2MBp2hjnzv1QtG4t3eO/DyZhLC','13912341234','13912341234@gmail.com','2023-02-27 16:09:09','2023-02-27 16:09:09',0);

/*Table structure for table `resource` */

DROP TABLE IF EXISTS `resource`;

CREATE TABLE `resource` (
  `id` bigint NOT NULL,
  `icon` varchar(255) DEFAULT NULL COMMENT '资源图标',
  `type` varchar(255) DEFAULT NULL COMMENT '资源类型',
  `name` varchar(255) DEFAULT NULL COMMENT '资源名称',
  `show_name` varchar(255) DEFAULT NULL COMMENT '资源展示名称',
  `level` int DEFAULT '1' COMMENT '级别，深度',
  `pid` bigint DEFAULT NULL COMMENT '父资源id',
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  `deleted` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `resource` */

insert  into `resource`(`id`,`icon`,`type`,`name`,`show_name`,`level`,`pid`,`created`,`updated`,`deleted`) values 
(391179018518598,'account','menu','account','账户',1,NULL,'2023-03-01 10:51:32','2023-03-01 10:51:32',0),
(391272015003717,'account2','menu','account2','账户2',2,391179018518598,'2023-03-01 17:09:56','2023-03-01 17:09:56',0),
(391272090009669,'account3','menu','account3','账户3',3,391272015003717,'2023-03-01 17:10:15','2023-03-01 17:10:15',0);

/*Table structure for table `resource_extra` */

DROP TABLE IF EXISTS `resource_extra`;

CREATE TABLE `resource_extra` (
  `id` bigint NOT NULL COMMENT '主键',
  `pid` bigint DEFAULT NULL COMMENT '父资源id',
  `rid` bigint DEFAULT NULL COMMENT '资源id',
  `distance` int DEFAULT NULL COMMENT '距离',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `resource_extra` */

/*Table structure for table `undo_log` */

DROP TABLE IF EXISTS `undo_log`;

CREATE TABLE `undo_log` (
  `branch_id` bigint NOT NULL COMMENT 'branch transaction id',
  `xid` varchar(128) NOT NULL COMMENT 'global transaction id',
  `context` varchar(128) NOT NULL COMMENT 'undo_log context,such as serialization',
  `rollback_info` longblob NOT NULL COMMENT 'rollback info',
  `log_status` int NOT NULL COMMENT '0:normal status,1:defense status',
  `log_created` datetime(6) NOT NULL COMMENT 'create datetime',
  `log_modified` datetime(6) NOT NULL COMMENT 'modify datetime',
  UNIQUE KEY `ux_undo_log` (`xid`,`branch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='AT transaction mode undo table';

/*Data for the table `undo_log` */

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
